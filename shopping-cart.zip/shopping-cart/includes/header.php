<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- <link rel="icon" href="assets/images/favicon.png" sizes="32x32" /> -->

    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" />
    <link rel="stylesheet" href="assets/css/main.min.css">
    <title>Shopping cart</title>

</head>

<body>
    <!-- <div class="cursor"></div> -->

    <header class="main-header">
        <div class="container h-100 d-flx flx-vcenter">
            <div class="header-right ml-auto mr-auto d-flx flx-vcenter">
                <nav class="main-nav">
                    <ul>
                        <li class="login-cart"><a href=""><img src="assets/images/cart.svg" alt="logo"></a></li>
                        <li class="login-li"><a href="">تسجيل دخول<img src="assets/images/user.svg" alt="logo"></a></li>
                    </ul>
                    <ul>
                        <li><a href="">طلب اون لاين</a></li>
                        <li><a href="">زيارة منزلية</a></li>
                        <li><a class="active" href="index.php">زيارة الفرع</a></li>
                    </ul>
                </nav>
            </div>
            <div class="logo">
                <a href="index.php">
                    <img src="assets/images/logo.png" alt="logo">
                </a>
            </div>
        </div>
    </header>