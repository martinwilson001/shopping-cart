<footer class="footer">
    <section class="footer-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-10">
                    <div class="col-lg-12">
                        <div class="row footer-content">
                            <div class="col-lg-4 col-sm-6 col-xs-6">
                                <h4>روابط إضافية</h4>
                                <ul>
                                    <li><a href="">الشروط و الأحكام</a></li>
                                    <li><a href="">سياسة الخصوصية</a></li>
                                    <li><a href="">الإستبدال و الإسترجاع</a></li>
                                </ul>
                            </div>
                            <div class="col-lg-4 col-sm-6 col-xs-6">
                                <h4>روابط مهمة</h4>
                                <ul>
                                    <li><a href="">زيارة فرع</a></li>
                                    <li><a href="">زيارة منزلية</a></li>
                                    <li><a href="">طلب اون لاين</a></li>
                                </ul>
                            </div>
                            <div class="col-lg-4">
                                <h4>من نحن</h4>
                                <p>للأقمشة الرجالية ‏خبرة دامت  عام في مجال
                                    الأقمشة الرجالية، أقمشة عالية الجودة من أرقى بيوت الأقمشة الرجالية
                                    ذات الماركات العالمية تتميز بجودة تعانق الطموح وتلبي الذوق الرفيع</p>
                            </div>
                        </div>
                    </div>
                </div>
                <article class="col-lg-2 footer-logo-white">
                    <img src="assets/images/logo.png">
                </article>
                <div class="social-media-wrap">
                    <ul>
                        <li><img src="assets/images/logo.png"></li>
                        <li><img src="assets/images/logo.png"></li>
                        <li><img src="assets/images/logo.png"></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <section class="sub-footer">
        <div class="container">
            <div class="cards-wrap">
            <ul>
                        <li><img src="assets/images/logo.png"></li>
                        <li><img src="assets/images/logo.png"></li>
                        <li><img src="assets/images/logo.png"></li>
                        <li><img src="assets/images/logo.png"></li>
                        <li><img src="assets/images/logo.png"></li>
                    </ul>
            </div>
            <div class="motto-wrap">
                <p>© 2023 صنع بإتقان على منصة O1</p>
            </div>
        </div>
    </section>
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <script sync src='//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.0.8/popper.min.js" crossorigin="anonymous"></script>
    <!-- <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script> -->
    <!-- Lazyload -->
    <script src="assets/js/vendors/lazyload-all.js" async=""></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
    <!-- <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.isotope/3.0.1/isotope.pkgd.min.js"></script> -->
    <!-- tweenmax animation -->
    <!-- <script type="text/javascript" src="assets/js/TweenMax.min.js"></script>
    <script type="text/javascript" src="assets/js/ScrollMagic.js"></script>
    <script type="text/javascript" src="assets/js/animation.gsap.min.js"></script>
    <script type="text/javascript" src="assets/js/animation.js"></script> -->
    <script src="https://kit.fontawesome.com/66e17fc1d7.js" crossorigin="anonymous"></script>
    <script type="text/javascript" src="assets/js/main.js"></script>
    <script>
        function loadJS(u) {
            var r = document.getElementsByTagName("script")[0],
                s = document.createElement("script");
            s.src = u;
            r.parentNode.insertBefore(s, r);
        }
    </script>
    
</footer>